# Validation

## Proof Strategy

Every slice must have deterministic focused tests, exact changed-path evidence,
a reviewed patch, and scratch forward/reverse proof. Phase gates verify the
combined package surface; the final gate runs the full Go suite, vet, web build,
binary build, and whitespace validation.

## Phase 1 — WebSocket Message Too Big

Status: approved on 2026-07-23.

Evidence revision:
`.kit/evidence/cliproxyapi-v7.2.93-backport/slices/P1-CLOSE/r01/`

- Baseline: `2960b690bf89232b8a23c5b8823fbe0ca831347f`.
- Patch SHA-256: `081c6029e14044651368ed6cc1a212148d791d0694fd7836228138c025d14427`.
- Forward scratch application matches the exact current six-file fingerprint.
- Reverse scratch application matches the exact baseline six-file fingerprint.
- Post-test fingerprint equals the pre-test fingerprint.
- Independent high-risk review verdict: `APPROVED`, zero verified Critical or
  Major findings.

Commands and observed results:

```text
go test ./internal/runtime/executor -run 'Test.*(MessageTooBig|1009)' -count=1
ok github.com/therealtinhtute/llmhub/internal/runtime/executor

go test ./sdk/cliproxy/auth -run 'Test.*(RequestScoped|Fallback)' -count=1
ok github.com/therealtinhtute/llmhub/sdk/cliproxy/auth

go test ./sdk/api/handlers/openai -run 'Test.*WebSocket.*(1009|MessageTooBig)' -count=1
ok github.com/therealtinhtute/llmhub/sdk/api/handlers/openai

go test ./internal/runtime/executor ./sdk/cliproxy/auth ./sdk/api/handlers/openai -count=1
ok github.com/therealtinhtute/llmhub/internal/runtime/executor
ok github.com/therealtinhtute/llmhub/sdk/cliproxy/auth
ok github.com/therealtinhtute/llmhub/sdk/api/handlers/openai
```

Acceptance covered:

- Close 1009 maps to structured request-scoped 413 `message_too_big`.
- Request-scoped classification prevents credential mutation, refresh, and
  fallback in immediate and streaming paths.
- Non-1009 and unobserved writer errors retain ordinary retry behavior.
- Handler rollback preserves transcript, output history, replay state, and tool
  repair/call caches.

## Phase 2 — Auth and CountTokens Reliability

Status: approved on 2026-07-23.

Reviewed slice evidence:

- `.kit/evidence/cliproxyapi-v7.2.93-backport/slices/P2-S1-cooldown-jitter/r01/`
  - patch SHA-256: `7e17ef3ab124b1fa713285fb984ac45722926121e4a2489fd4572beb068af875`;
  - independent verdict: `APPROVED`.
- `.kit/evidence/cliproxyapi-v7.2.93-backport/slices/P2-S2-error-classification/r04/`
  - patch SHA-256: `0f0b7c79e4627bc956a333ce64604dc4ef6a8357324be7915655cc660e0325ec`;
  - immutable result tree: `98d750898d239533918d092276faf9520a64adb1`;
  - independent verdict: `APPROVED`.

Rejected and superseded P2-S2 revisions remain preserved:

- `r01`: unbounded `invalid_grant` matching and missed wrapped nested
  `model_not_found`;
- `r02`: frozen patch omitted the final `strconv` import and did not match its
  tested result tree;
- `r03`: frozen patch retained structured-JSON whole-message fallback despite an
  inconsistent approval artifact; it was reversed from main before applying
  reviewed `r04`.

Commands and observed results:

```text
go test ./sdk/cliproxy/auth ./internal/api/modules/amp -count=1
ok github.com/therealtinhtute/llmhub/sdk/cliproxy/auth
ok github.com/therealtinhtute/llmhub/internal/api/modules/amp

go test ./...
all packages passed

go vet ./...
pass

go build ./...
pass

git diff --check
pass
```

Acceptance covered:

- repeated and concurrent quota failures do not advance backoff during an active
  recovery window;
- clamp-before-jitter never exceeds the configured maximum and preserves
  `disableCooling` behavior;
- only HTTP 400/401 exact or bounded `invalid_grant` failures enter the 30-minute
  suspension and credential-fallback path;
- longer identifiers and unrelated HTTP 400 errors retain request-invalid
  behavior;
- generic CountTokens endpoint 404 failures retain counters, persistence, and
  hooks without changing registry or scheduler availability;
- explicit top-level, nested, wrapped, and joined `model_not_found` failures
  remain availability-changing;
- Amp inherits the shared conductor policy without production route changes.

Decision record:
`docs/decisions/0010-auth-cooldown-and-error-classification.md`.

## Remaining Phases

Phase 3 through Phase 5 and the final evidence gate remain to be recorded below
as their reviewed fingerprints are approved.
